/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.airlift.tpch.star;

import io.airlift.tpch.snow.Part;
import io.airlift.tpch.snow.PartSupplier;
import io.airlift.tpch.snow.Supplier;

public class PartSupplierStar{
//    private final long rowNumber;
    private final Part part; 
    private final Supplier supplier; 
    private final PartSupplier partSupplier;
    private final String relationName ="PartSupplierStar"; 
    
    public static String partProjection[] = {"partKey", "name", "manufacturer", "brand", "type", "size", "container", "retailPrice"};
    public static String supplierProjection[] = {"supplierKey","name","address","nationKey","phone","accountBalance"};
    public static String partSupplierProjection[] = {"partKey","supplierKey", "availableQuantity","supplyCost"};
    
    public PartSupplierStar(Part part, Supplier supplier, PartSupplier partSupplier)
    {
    	this.part = part; this.supplier = supplier; this.partSupplier = partSupplier;
    	part.setProjection(partProjection); 
    	supplier.setProjection(supplierProjection); 
    	partSupplier.setProjection(partSupplierProjection);         
    }

	public Part getPart()  {   return part;   }
    public Supplier getSupplier()  {   return supplier;   }
    public PartSupplier getPartSupplier()  {   return partSupplier;   }

    public String toLine(){
    	return part.toLine() + "|"+ supplier.toLine() + "|" + partSupplier.toLine();    }
    public String toCSV(String separator){
    	return part.toCSV(separator) + separator+ supplier.toCSV(separator) + separator + partSupplier.toCSV(separator);    }
    public String toXML(){
    	return "<"+relationName+">\n"+
    			part.toXML() + "\n"+ supplier.toXML() + "\n" + partSupplier.toXML()+"\n"+
    			"</"+relationName+">"; 
    	}
    public String toJson(){
    	String partStr = part.toJson().trim(); 
    	String suppStr = supplier.toJson().trim();
    	String partSuppStr = partSupplier.toJson().trim(); 
    	return "{"+ 
    			partStr.substring(1, partStr.length() -1) + ", " +
    			suppStr.substring(1, suppStr.length() -1) + ", "+ 
    			partSuppStr.substring(1, partSuppStr.length() -1) + "}"; 
    }
    
    
    public static void main(String argz[]){
    	Part p = new Part(1,1,"a","a","a","a",1,"a",1,"a");
    	PartSupplier ps = new PartSupplier(1,1,1,798,1,"a");
    	Supplier s = new Supplier(1, 1,"a", "bb", 6, "xp", 3, "aaa"); 
    	PartSupplierStar x = new PartSupplierStar(p, s, ps);
    	System.out.println(x); 
    	System.out.println(x.toLine());
    	System.out.println(x.toJson());
    	System.out.println(x.toXML());
    	System.out.println(x.toCSV(","));
    }    
}
