package io.airlift.tpch.star;

import java.util.Iterator;

import io.airlift.tpch.snow.Part;
import io.airlift.tpch.snow.PartGenerator;
import io.airlift.tpch.snow.PartSupplier;
import io.airlift.tpch.snow.PartSupplierGenerator;
import io.airlift.tpch.snow.Supplier;
import io.airlift.tpch.snow.SupplierGenerator;
import io.airlift.tpch.snow.PartGenerator.PartGeneratorIterator;
import io.airlift.tpch.snow.SupplierGenerator.SupplierGeneratorIterator;

public class PartSupplierStarGenerator {

	int scaleFactor; 
	int step = 1; int children = 1; // default values 

	public PartSupplierStarGenerator(int scaleFactor){this.scaleFactor = scaleFactor;}
	
    public static String headers[] = {"partKey","supplierKey","availableQuantity","supplyCost","comment"};;   
    public static String types[] = {"n","n","n","m", "s"};
	
	public void generate(){
		SupplierGenerator suppGen = new SupplierGenerator(scaleFactor, step, children);	
		PartGenerator partGen = new PartGenerator(scaleFactor, step, children);
		PartSupplierGenerator partSuppGen = new PartSupplierGenerator(scaleFactor, step, children);
		SupplierGeneratorIterator suppIt = (SupplierGeneratorIterator) suppGen.iterator();
		PartGeneratorIterator partIt = (PartGeneratorIterator) partGen.iterator();
		Iterator<PartSupplier> partSuppIt = partSuppGen.iterator();
		for (int i=0; i<PartGenerator.SCALE_BASE * scaleFactor; i++){
			try{
				PartSupplier partSupp = partSuppIt.next();
				Part part = partIt.makePart(partSupp.getPartKey());  
				Supplier supp = suppIt.makeSupplier(partSupp.getSupplierKey());
				System.out.println(supp.toJson());
				System.out.println(part.toJson());
				System.out.println(partSupp.toJson());

				PartSupplierStar pss = new PartSupplierStar(part, supp, partSupp); 
				System.out.println("* "+ pss.toJson());
				
			}catch(Exception e){System.out.println("Warning: "+ e.getLocalizedMessage()); e.printStackTrace();}
			//Part part = partIt.next(); 
			
			if (i > 3) return;
			System.out.println(); 
		}
	}
	
	
	
	public static void main(String[] args) {
		PartSupplierStarGenerator psgen = new PartSupplierStarGenerator(1); 
		psgen.generate();
	}

}
