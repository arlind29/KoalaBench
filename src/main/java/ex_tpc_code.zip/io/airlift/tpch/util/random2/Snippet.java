package io.airlift.tpch.util.random2;

public class Snippet {
	public static void main(String[] args) {
		System.getProperty("user.dir");
	}
}

