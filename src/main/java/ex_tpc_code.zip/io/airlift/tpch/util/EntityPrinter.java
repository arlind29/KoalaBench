package io.airlift.tpch.util;

import java.io.BufferedWriter;
import java.io.FileWriter;

import io.airlift.tpch.main.TpchEntity;

public class EntityPrinter {

	
	
	public void print(Iterable<? extends TpchEntity> entities, String filename, String format){
        BufferedWriter bw ; 
		try{
			bw = new BufferedWriter(new FileWriter(filename+"."+format)); 
    		for (TpchEntity entity : entities) {
                bw.write(printByFormat(entity, format)); 
                bw.write('\n');
            }		        	
    		bw.close(); 
        }catch(Exception e){e.printStackTrace();} 
	}
	
	public String printByFormat(TpchEntity entity, String format){
		if (format=="json") return entity.toJson(); 
		if (format=="csv") return entity.toCSV(",");
		if (format=="xml") return entity.toXML();
		return entity.toLine();
	}
	
}
