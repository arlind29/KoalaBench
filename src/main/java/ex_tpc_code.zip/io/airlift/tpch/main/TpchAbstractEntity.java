/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.airlift.tpch.main;

import java.util.HashMap;

public abstract class TpchAbstractEntity implements TpchEntity 
{
	protected  final long rowNumber;
	public long getRowNumber(){return rowNumber;}
	private boolean projectAll = true;
	
	protected TpchEntityInstance entity; 
	
	protected String headers[];
	protected String values[];
	protected String[] types;
	protected String relationName; 
	protected HashMap<String, Boolean> projMap = new HashMap<String, Boolean>(); // projection map
	
	public String[] headers(){return entity.headers;} 
	public String[] values(){return entity.values;}
	public String[] types(){return entity.types;}
	
	public HashMap<String, Boolean> getProjectionMap(){return entity.projMap;}
	public String getRelationName(){return entity.relationName;}
    
	public void setProjection(String[] projHeaders){
		entity.setProjection(projHeaders); 		
	}
    
	public TpchAbstractEntity(long rowNumber){this.rowNumber = rowNumber;}
	
    @Override
    public String toLine() { 	
    	//return String.join("|", values);
    	String out = "";  int count =0; 
    	for (int i=0; i<values.length; i++){
    		if (projectAll || projMap.get(headers[i])!=null) {
    			out += addQuotes(values[i], types[i]);
    			count++;
    			if ((projectAll || projMap.size()>count) && i!=headers.length-1) out += "|";
    		} 
    	}
    	out+=addQuotes(values[values.length-1], types[values.length-1]); 
    	return out; 
    	
    }
    @Override
    public String toJson(){
    	String out= "{"; int count = 0; 
    	for (int i=0; i<headers.length; i++){ 
    		if (projectAll || projMap.get(headers[i])!=null) {
    			out+=headers[i]+":" +addQuotes(values[i],types[i]);
        		count++; 
        		if ((projectAll || projMap.size()>count) && i!=headers.length-1) out+=", ";
    		}
    	}    	
    	return out+ "}"; 
    }
    
    @Override
    public String toXML(){
    	String out = "<"+relationName+">\n"; 
    	for (int i=0; i<headers.length; i++){
    		if (projectAll || projMap.get(headers[i])!=null) out+="\t<"+headers[i]+">" + addQuotes(values[i],types[i]) +"</"+headers[i]+">\n";
    	}
    	return out+ "</"+relationName+">";
    }
    
    @Override
    public String toCSV(String separator){
    	String out = ""; int count =0;  
    	for (int i=0; i<values.length; i++){
    		if (projectAll || projMap.get(headers[i])!=null) {
    			out += addQuotes(values[i],types[i])+ separator;
        		count++; 
        		if ((projectAll || projMap.size()>count) && i!=headers.length-1) out += "|"; 
    		}
    	}
    	return out; 
    	//return String.join(separator, values);  
    }
    
    private String addQuotes(String val, String type){
    	if (type.equals("n")) return val; else return "\""+val+"\"";
    }
}
