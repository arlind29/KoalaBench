package io.airlift.tpch.main;

import java.util.HashMap;

public class TpchEntityInstance {
	private boolean projectAll = true;

	protected String headers[];
	protected String values[];
	protected String[] types;
	protected String relationName; 
	protected HashMap<String, Boolean> projMap = new HashMap<String, Boolean>(); // projection map
	
	public String[] headers(){return headers;} 
	public String[] values(){return values;}
	public String[] types(){return types;}
	public HashMap<String, Boolean> getProjectionMap(){return projMap;}
	public String getRelationName(){return relationName;}
    
	public void setProjection(String[] projHeaders){
		projMap = new HashMap<String, Boolean>();
    	for (String header: projHeaders){ projMap.put(header, true);}
		projectAll=false; 
		
	}
    
	public TpchEntityInstance(String[] headers, String[] types, String values[]){
		this.headers = headers; 
		this.types = types; 
		this.values = values; 
	}
	
    public String toLine() { 	
    	//return String.join("|", values);
    	String out = "";  int count =0; 
    	for (int i=0; i<values.length; i++){
    		if (projectAll || projMap.get(headers[i])!=null) {
    			out += addQuotes(values[i], types[i]);
    			count++;
    			if ((projectAll || projMap.size()>count) && i!=headers.length-1) out += "|";
    		} 
    	}
    	out+=addQuotes(values[values.length-1], types[values.length-1]); 
    	return out; 
    	
    }
    public String toJson(){
    	String out= "{"; int count = 0; 
    	for (int i=0; i<headers.length; i++){ 
    		if (projectAll || projMap.get(headers[i])!=null) {
    			out+=headers[i]+":" +addQuotes(values[i],types[i]);
        		count++; 
        		if ((projectAll || projMap.size()>count) && i!=headers.length-1) out+=", ";
    		}
    	}    	
    	return out+ "}"; 
    }
    
    public String toXML(){
    	String out = "<"+relationName+">\n"; 
    	for (int i=0; i<headers.length; i++){
    		if (projectAll || projMap.get(headers[i])!=null) out+="\t<"+headers[i]+">" + addQuotes(values[i],types[i]) +"</"+headers[i]+">\n";
    	}
    	return out+ "</"+relationName+">";
    }
    
    public String toCSV(String separator){
    	String out = ""; int count =0;  
    	for (int i=0; i<values.length; i++){
    		if (projectAll || projMap.get(headers[i])!=null) {
    			out += addQuotes(values[i],types[i])+ separator;
        		count++; 
        		if ((projectAll || projMap.size()>count) && i!=headers.length-1) out += "|"; 
    		}
    	}
    	return out; 
    	//return String.join(separator, values);  
    }
    
    private String addQuotes(String val, String type){
    	if (type.equals("n")) return val; else return "\""+val+"\"";
    }
	

}
